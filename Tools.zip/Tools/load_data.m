function [dataX, dataY] = load_data(filename)
    % Scene 294,295
    % Yeast 103,104
    % Emotions 72,73
    % Mediamill, 120
    % Corel, 499
    % Enron 1001
    % medical 1449
    fileNames = dirr(['./Data/' filename]);

    trfile = load([fileNames(1).folder,'/',fileNames(1).name]);
    tsfile = load([fileNames(1+1).folder,'/',fileNames(1+1).name]);

    if strcmp(filename, 'corel')
        temp_m = 499;
    elseif strcmp(filename, 'scene')
        temp_m = 294;
    elseif strcmp(filename, 'enron')
        temp_m = 1001;
    elseif strcmp(filename, 'yeast')
        temp_m = 103;
    elseif strcmp(filename, 'mediamill')
        temp_m = 120;
    elseif strcmp(filename, 'emotions')
        temp_m = 72;
    elseif strcmp(filename, 'medical')
        temp_m = 1449;  
    else
        return;
    end

    temp_n = temp_m + 1;

    trainData = trfile(:,1:temp_m)';
    trainTarget = trfile(:,temp_n:end)';
    testData = tsfile(:,1:temp_m)';
    testTarget = tsfile(:,temp_n:end)';
    
    dataX = [trainData, testData];
    dataY = [trainTarget, testTarget];

end