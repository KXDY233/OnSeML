function Result = getResult(Yc,Yt)

HammingLoss = Hamming_loss(Yc,Yt);
OneError = One_error(Yc,Yt);
Coverage = coverage(Yc,Yt);
Average_Precision = Average_precision(Yc,Yt);
fScore = FScore(Yc,Yt);
Exact_Match = Exact_match(Yc,Yt);
MacroF1 = Macro_F1(Yt,Yc);
MicroF1 = Micro_F1(Yt,Yc);

Result = [HammingLoss, OneError, Coverage, Average_Precision ...
    fScore, MacroF1, MicroF1];

end