function [idx1, Yf] = find_k_max_each_column(M, k)
    

    idx1 = [];
    Yf = zeros(size(M));
    for i = 1:size(M,2)
        [~,tid1] = find_k_max(M(:,i), k);
        M(tid1,i) = -inf;
        Yf(tid1,i) = 1;
        idx1 = [idx1; tid1];
        
    end

end