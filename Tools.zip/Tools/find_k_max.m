function [value, idx]=find_k_max(x,k)
value = zeros(1,k);
idx   = zeros(1,k);
m = min(x);
for j = 1:k
    [value(j), idx(j)] = max(x);
    x(idx(j))=m;
end